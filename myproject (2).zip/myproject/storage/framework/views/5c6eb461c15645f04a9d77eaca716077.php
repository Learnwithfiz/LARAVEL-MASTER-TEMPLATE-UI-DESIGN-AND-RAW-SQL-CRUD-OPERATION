<footer class="myfooter">
    <h1 class="text-center">Contact Me</h1>
   <div class="container">
     <div class="row text-center mt-5">
        <div class="col-lg-4">
            <h3>Contact us</h3>
            <p>Phone: +8801718465130</p>
            <p><a href="">Facebook</a></p>
            <p><a href="">website</a></p>
            <p><a href="">email: iff@gmail.com</a></p>
        </div>
        <div class="col-lg-3">
           <h3>Location</h3>
           <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d233668.43066476667!2d90.25446913226716!3d23.780548981026623!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b8b087026b81%3A0x8fa563bbdd5904c2!2sDhaka!5e0!3m2!1sen!2sbd!4v1682562664645!5m2!1sen!2sbd" width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <div class="col-lg-3">
           <h3>Office</h3>
           <p>Banani , Dhaka </p>
           <p>Main Office : Dhanmondi , Dhaka  </p>
        </div>
     </div>
   </div>
</footer><?php /**PATH C:\Users\User\Desktop\Batch 02 Laravel\Project\myproject\resources\views/App/footer.blade.php ENDPATH**/ ?>