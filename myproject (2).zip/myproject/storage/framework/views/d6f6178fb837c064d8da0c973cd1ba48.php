
<?php $__env->startSection('keyTitle','view page'); ?>
 <?php $__env->startSection('MainContent'); ?>
 <?php $__currentLoopData = $key; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php if('msgKey'): ?>
            <h3 class="alert alert-danger"> <?php echo e(session('msgKey')); ?></h3>
           <?php endif; ?>
 <form class="form" method="post"  action="<?php echo e(url('/update/'.$item->id)); ?>">
    <?php echo csrf_field(); ?>
    <input type="text" value="<?php echo e($item->name); ?>" name="name" placeholder="enter name" class="form-control">
    <input type="email"value="<?php echo e($item->email); ?>" name="email" placeholder="enter email" class="form-control">
    <input type="number"value="<?php echo e($item->phone); ?>"name="number" placeholder="enter phone" class="form-control">
    <textarea  name="msg"value="<?php echo e($item->msg); ?>" placeholder="write your  message...." class="form-control text-area" id="" cols="30" rows="10"></textarea>
    <button class="btn btn-primary form-control">Update</button>
    <a href="<?php echo e(url('/view')); ?>">view </a>
  </form>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('App.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\Batch 02 Laravel\Project\myproject\resources\views/showInfo.blade.php ENDPATH**/ ?>