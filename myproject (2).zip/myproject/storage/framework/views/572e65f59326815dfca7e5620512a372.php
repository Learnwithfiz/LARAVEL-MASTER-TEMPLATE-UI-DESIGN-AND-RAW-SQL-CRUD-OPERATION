
<?php $__env->startSection('keyTitle','view page'); ?>
 <?php $__env->startSection('MainContent'); ?>
   <div class="container">
     <div class="row">
        <h1>user Info from contact table</h1>
        <div class="col-lg-8">
            <?php if('msgKey'): ?>
            <h3 class="alert alert-danger"> <?php echo e(session('msgKey')); ?></h3>
           <?php endif; ?>
            <table class="table">
                <th>name</th>
                <th>email</th>
                <th>phone</th>
                <th>msg</th>
                <th>edit</th>
                <th>delete</th>
        
                <tbody>
                  
                    <?php $__currentLoopData = $userInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->email); ?></td>
                        <td><?php echo e($item->phone); ?></td>
                        <td><?php echo e($item->msg); ?></td>
                        <td><a href="<?php echo e(url('/edit/'.$item->id)); ?>"><button class="btn btn-success">edit</button></a></td>
                        <td><a href="<?php echo e(url('/delete/'.$item->id)); ?>"><button class="btn btn-warning">delete</button></a></td>
                    </tr> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
           </table>
        </div>
     </div>
   </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('App.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\Batch 02 Laravel\Project\myproject\resources\views/view.blade.php ENDPATH**/ ?>