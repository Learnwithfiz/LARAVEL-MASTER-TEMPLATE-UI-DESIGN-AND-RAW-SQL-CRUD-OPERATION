<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('keyTitle'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('CSS/custom.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/bootstrap.min.css')); ?>">
</head>
<body>
  
    <?php echo $__env->make('App.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     
     <?php echo $__env->yieldContent('MainContent'); ?>

    <?php echo $__env->make('App.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <script src="<?php echo e(asset('bootstrap/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('JS/custom.js')); ?>"></script>
</body>
</html><?php /**PATH C:\Users\User\Desktop\Batch 02 Laravel\Project\myproject\resources\views/App/app.blade.php ENDPATH**/ ?>